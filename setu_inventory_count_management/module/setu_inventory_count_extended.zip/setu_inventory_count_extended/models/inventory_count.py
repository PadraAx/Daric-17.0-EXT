from odoo import fields, models, api, _
from odoo.exceptions import UserError


class StockInvCount(models.Model):
    _inherit = 'setu.stock.inventory.count'

    product_details_ids = fields.One2many('setu.product.wise.abc.fsn', 'inventory_count_id')

    def get_products_from_setu_reports(self):
        action = self.sudo().env.ref('setu_inventory_count_extended.get_products_from_setu_reports_act_window').read()[0]
        wizard = self.env['get.products.from.adv.inv.rep.wizard'].create({})
        wizard.warehouse_ids = self.warehouse_id
        action.update({
            'res_id': wizard.id
        })
        return action

    def remove_count_lines(self):
        action = self.sudo().env.ref('setu_inventory_count_extended.get_products_details_from_setu_reports_act_window').read()[0]
        wizard = self.env['get.products.from.adv.inv.rep.wizard'].create({})
        wizard.warehouse_ids = self.warehouse_id
        action.update({
            'res_id': wizard.id
        })
        return action

    def create_session(self):
        if self.type == 'Multi Session':
            is_multi_session = True
        else:
            is_multi_session = False
        session_creator_wiz = self.env['inventory.session.creator'].create({'inventory_count_id': self.id,
                                                                            'is_multi_session': is_multi_session})
        products = self.product_ids.ids
        session_creator_wiz.write({'product_ids': [(6, 0, products)]})

        if self.product_details_ids:
            return {
                'name': 'Create Session By',
                'view_type': 'form',
                'view_mode': 'form',
                'context': {'default_inventory_count_id': self.id},
                'res_model': 'inventory.session.creator',
                'type': 'ir.actions.act_window',
                'view_id': self.sudo().env.ref('setu_inventory_count_extended.inventory_session_details_form_view').id,
                'target': 'new'
            }
        return {
            'name': 'Create Session',
            'view_type': 'form',
            'view_mode': 'form',
            'context': {'products': products},
            'res_model': 'inventory.session.creator',
            'type': 'ir.actions.act_window',
            'view_id': self.sudo().env.ref('setu_inventory_count_management.inventory_session_creator_form_view').id,
            'res_id': session_creator_wiz.id,
            'target': 'new'
        }

    @api.onchange('product_details_ids')
    def onchange_product_details_ids(self):
        if self._origin and self._origin.product_details_ids:
            list_before_delete = self._origin.product_details_ids.ids
            list_after_removed_products = self.product_details_ids.ids
            removed_line = list(set(list_before_delete) - set(list_after_removed_products))
            if removed_line:
                removed_product = self.env['setu.product.wise.abc.fsn'].search([('id', 'in', removed_line)]).product_id
                for prod in removed_product:
                    self.write({'product_ids': [(3, prod.id)]})

    @api.onchange('product_ids')
    def onchange_product_ids(self):
        if self._origin and self._origin.product_ids:
            list_before_delete = self._origin.product_ids.ids
            list_after_removed_products = self.product_ids.ids
            removed_line = list(set(list_before_delete) - set(list_after_removed_products))
            if removed_line:
                removed_product = self.env['setu.product.wise.abc.fsn'].search([('product_id', 'in', removed_line),
                                                                                ('inventory_count_id', '=', self._origin.id)])
                for prod in removed_product:
                    self.write({'product_details_ids': [(3, prod.id)]})
