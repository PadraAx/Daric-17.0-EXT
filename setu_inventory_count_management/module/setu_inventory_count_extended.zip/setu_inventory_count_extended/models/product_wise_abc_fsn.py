from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class SetuProductWiseAbcFsn(models.Model):
    _name = 'setu.product.wise.abc.fsn'
    _description = 'Product Wise ABC/FSN'

    product_id = fields.Many2one('product.product', string='Product')
    product_tmpl_id = fields.Many2one(
        'product.template', string='Product Template',
        related='product_id.product_tmpl_id')
    category_id = fields.Many2one(related='product_tmpl_id.categ_id')
    barcode = fields.Char(related='product_tmpl_id.barcode')
    fsn = fields.Char(string="FSN")
    abc = fields.Char(string="ABC")
    inventory_count_id = fields.Many2one('setu.stock.inventory.count')

    # def unlink(self):
    #     if self.inventory_count_id.state == 'Draft' and self.inventory_count_id.count_session_ids > 0 or self.inventory_count_id.state != 'Draft':
    #         raise ValidationError(_("You cannot remove the Product because one or more session has been created."))
    #     if not self:
    #         return True
    #     products = self.product_id
    #     product_ids = self.inventory_count_id.product_details_ids.filtered(lambda p: p.product_id in products.ids)
    #     for product in product_ids:
    #         self.inventory_count_id.product_details_ids = [(3, product.id)]
    #     return super(SetuProductWiseAbcFsn, self).unlink()

