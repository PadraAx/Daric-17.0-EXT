from datetime import timedelta
from datetime import datetime, date
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class StockInvCountPlanner(models.Model):
    _inherit = 'setu.stock.inventory.count.planner'

    report_type = fields.Selection([('manually', 'Manually'), ('ABC', 'ABC'), ('FSN', 'FSN')], default='manually')
    stock_movement_type = fields.Selection([('all', 'All'),
                                            ('Fast Moving', 'Fast Moving'),
                                            ('Slow Moving', 'Slow Moving'),
                                            ('Non Moving', 'Non Moving')], "FSN Classification", default="all")
    abc_analysis_type = fields.Selection([('all', 'All'),
                                          ('A', 'High Sales (A)'),
                                          ('B', 'Medium Sales (B)'),
                                          ('C', 'Low Sales (C)')], "ABC Classification", default="all")

    def verify_inventory_count_planing(self):
        if self.planing_frequency <= 0:
            raise ValidationError('Please enter Frequency Days.')
        if not self.product_ids and self.report_type == 'manually':
            raise ValidationError('Please select Product.')
        self.write({'state': 'verified'})
        return True

    def create_inventory_count_record(self):
        inventory_count_obj = self.env['setu.stock.inventory.count']
        vendor_product_dict = self.get_approver_product_mapping_dict()
        for approver_id, product_ids in vendor_product_dict.items():
            vals = self.prepare_vales_for_inventory_count(approver_id, product_ids)
            rec = inventory_count_obj.search([('planner_id', '=', self.id), ('state', '=', 'draft')])
            if rec:
                rec.product_ids and rec.product_ids.unlink()
                rec.write(vals)
            else:
                mail_obj = self.env['mail.mail']
                rec = inventory_count_obj.create(vals)
                rec.write({'planner_id': self.id, 'message_follower_ids': [(4, rec.approver_id.partner_id.id)]})
                email_template = self.sudo().sudo().env.ref(
                    'setu_inventory_count_management.mail_template_request_for_inventory_count', False)
                partners = rec.message_follower_ids.mapped('partner_id')
                # mail_body = email_template._render({}, engine='ir.qweb', minimal_qcontext=True)
                mail_mail = email_template and email_template.send_mail(rec.id) or False
                mail_mail = mail_mail and mail_obj.sudo().browse(mail_mail)
                if mail_mail:
                    mail_mail.recipient_ids = [(6, 0, [rec.approver_id.partner_id.id])]
                    mail_mail.send()
            self.write({'previous_execution_date': datetime.today().date(),
                        'next_execution_date': datetime.today().date() + timedelta(days=self.planing_frequency)
                        })
            if self.report_type != 'manually':
                product_ids = False
                field_name = self.report_type.lower()
                if self.report_type == 'FSN':
                    product_ids = [(val['product_id'], val['stock_movement']) for val in
                                   self.get_inventory_fsn_analysis_report_data(self.stock_movement_type)]
                elif self.report_type == 'ABC':
                    product_ids = [(val['product_id'], val['analysis_category']) for val in
                                   self.get_abc_sales_analysis_report_data(self.abc_analysis_type)]
                    product_ids = list(
                        filter(lambda p: self.env['product.product'].sudo().browse(p[0]).type == 'product',
                               product_ids))
                if product_ids:
                    self.env['get.products.from.adv.inv.rep.wizard'].set_products_in_inventory_count(product_ids,
                                                                                                     field_name, rec)

    def get_abc_sales_analysis_report_data(self, classification=False, whs={}, start_date=False, end_date=False):
        days = self.past_history_days
        start_date = start_date or date.today() - timedelta(days=days)
        end_date = end_date or date.today()

        company_ids = set(self.env.context.get('allowed_company_ids', False) or self.env.user.company_ids.ids) or {}

        # warehouses = {self.warehouse_id.id}

        # get_products_overstock_data(company_ids, product_ids, category_ids, warehouse_ids, start_date, end_date, advance_stock_days)
        query = """
                Select * from get_abc_inventory_count_data('%s','{}','{}','%s','%s','%s', '%s')
            """ % (company_ids, whs, start_date, end_date, classification)
        print(query)
        self._cr.execute(query)
        sales_data = self._cr.dictfetchall()
        return sales_data

    def get_inventory_fsn_analysis_report_data(self, classification=False, whs={}, start_date=False, end_date=False):
        days = self.past_history_days
        start_date = start_date or date.today() - timedelta(days=days)
        end_date = end_date or date.today()

        company_ids = set(self.env.context.get('allowed_company_ids', False) or self.env.user.company_ids.ids) or {}

        # warehouses = {self.warehouse_id.id}

        # get_products_overstock_data(company_ids, product_ids, category_ids, warehouse_ids, start_date, end_date, advance_stock_days)
        query = """
                Select * from get_inventory_fsn_inventory_count_report('%s','{}','{}','%s','%s','%s', '%s')
            """ % (company_ids, whs, start_date, end_date, classification)
        self._cr.execute(query)
        stock_data = self._cr.dictfetchall()
        return stock_data

