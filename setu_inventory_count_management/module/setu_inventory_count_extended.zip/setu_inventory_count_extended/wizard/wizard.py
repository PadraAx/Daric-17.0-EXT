from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class SessionCreator(models.TransientModel):
    _inherit = 'inventory.session.creator'
    
    session_for_all_products = fields.Boolean(string='Session for All Products?')
    report_type = fields.Selection([('ABC', 'ABC'), ('FSN', 'FSN')], default='ABC')
    abc_all = fields.Boolean(string='All')
    abc_a = fields.Boolean(string='High Sales (A)')
    abc_b = fields.Boolean(string='Medium Sales (B)')
    abc_c = fields.Boolean(string='Low Sales (C)')
    fsn_all = fields.Boolean(string='All')
    fsn_f = fields.Boolean(string='Fast Moving')
    fsn_s = fields.Boolean(string='Slow Moving')
    fsn_n = fields.Boolean(string='Non Moving')

    def create_session(self):
        if not self.session_for_all_products:
            products = []
            type = self.report_type
            if type == 'ABC':
                if self.abc_all:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.abc != False)
                if self.abc_a:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.abc == 'A')
                if self.abc_b:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.abc == 'B')
                if self.abc_c:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.abc == 'C')
            elif type == 'FSN':
                if self.fsn_all:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.fsn != False)
                if self.fsn_f:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.fsn == 'Fast Moving')
                if self.fsn_s:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.fsn == 'Slow Moving')
                if self.fsn_n:
                    products += self.inventory_count_id.product_details_ids.filtered(lambda p: p.fsn == 'Non Moving')
            details_product_ids = self.inventory_count_id.product_details_ids.product_id.ids
            product_ids = self.inventory_count_id.product_ids.ids
            remaining_products = list(set(product_ids) - set(details_product_ids))
            product_ids = [product.product_id.id for product in products]
            product_ids += remaining_products
        else:
            product_ids = self.inventory_count_id.product_ids.ids
        if not product_ids:
            raise ValidationError(_("No product found to create a new session as per your selected ABC/FSN "
                                    "classification."))
        if self.inventory_count_id.type == 'Multi Session':
            is_multi_session = True
        else:
            is_multi_session = False
        session_creator_wiz = self.env['inventory.session.creator'].create(
            {'inventory_count_id': self.inventory_count_id.id,
             'is_multi_session': is_multi_session})
        session_creator_wiz.write({'product_ids': [(6, 0, product_ids)]})
        return {
            'name': 'Create Session',
            'view_type': 'form',
            'view_mode': 'form',
            'context': {'products': product_ids},
            'res_model': 'inventory.session.creator',
            'type': 'ir.actions.act_window',
            'view_id': self.sudo().env.ref('setu_inventory_count_management.inventory_session_creator_form_view').id,
            'res_id': session_creator_wiz.id,
            'target': 'new'
        }
