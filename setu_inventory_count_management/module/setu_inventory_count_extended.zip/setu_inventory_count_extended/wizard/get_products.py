from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class GetProducts(models.TransientModel):
    _name = 'get.products.from.adv.inv.rep.wizard'

    report_type = fields.Selection([('ABC', 'ABC'), ('FSN', 'FSN')], default='ABC')
    stock_movement_type = fields.Selection([('all', 'All'),
                                            ('Fast Moving', 'Fast Moving'),
                                            ('Slow Moving', 'Slow Moving'),
                                            ('Non Moving', 'Non Moving')], "FSN Classification",
                                           default="all")
    abc_analysis_type = fields.Selection([('all', 'All'),
                                          ('A', 'High Sales (A)'),
                                          ('B', 'Medium Sales (B)'),
                                          ('C', 'Low Sales (C)')], "ABC Classification",
                                         default="all")
    start_date = fields.Datetime()
    end_date = fields.Datetime()
    warehouse_ids = fields.Many2many("stock.warehouse", "st_ware_get_pro_rel", string="Warehouses")
    product_category_ids = fields.Many2many("product.category", 'pro_cat_get_pro_rel', string="Product Categories")
    product_ids = fields.Many2many("product.product", "pro_pro_get_pro_rel", string="Products")

    def set_products_in_inventory_count(self, product_ids, field_name, count=False):
        product_category_ids = []
        if not count:
            count = self.env['setu.stock.inventory.count'].browse(self.env.context.get('active_id', False))
        for prod in product_ids:
            existing_product = self.env['setu.product.wise.abc.fsn'].search([('product_id', '=', prod[0]),
                                                                             ('inventory_count_id', '=', count.id)])
            if existing_product:
                existing_product.write({field_name: prod[1]})
            else:
                product = self.env['product.product'].browse(prod[0])
                record = self.env['setu.product.wise.abc.fsn'].create({
                    'product_id': product.id,
                    'category_id': product.categ_id,
                    'inventory_count_id': count.id,
                    field_name: prod[1],
                })

        res_list = [x[0] for x in product_ids]
        product_ids = self.env['product.product'].browse(res_list)
        product_details_ids = self.env['setu.product.wise.abc.fsn'].browse(product_category_ids)
        count.product_ids |= product_ids
        count.product_details_ids |= product_details_ids

    def get_products_from_setu_reports(self):
        product_ids = False
        field_name = self.report_type.lower()
        whs = {self.warehouse_ids.id}
        if self.report_type == 'FSN':
            data = self.env['setu.stock.inventory.count.planner'].get_inventory_fsn_analysis_report_data(
                classification=self.stock_movement_type, whs=whs, start_date=self.start_date,
                end_date=self.end_date)
            product_ids = [(val['product_id'], val['stock_movement']) for val in data]
        elif self.report_type == 'ABC':
            product_ids = [(val['product_id'], val['analysis_category']) for val in
                           self.env['setu.stock.inventory.count.planner'].get_abc_sales_analysis_report_data(
                               classification=self.abc_analysis_type, whs=whs, start_date=self.start_date,
                               end_date=self.end_date
                           )]
            product_ids = list(
                filter(lambda p: self.env['product.product'].sudo().browse(p[0]).type == 'product', product_ids))
        if product_ids:
            self.set_products_in_inventory_count(product_ids, field_name)
        else:
            raise ValidationError(_('No products found.'))

    def remove_products_from_setu_reports(self):
        product_detail = []
        domain = []
        categories = self.product_category_ids
        specific_products = self.product_ids
        abc_value = self.abc_analysis_type
        fsn_value = self.stock_movement_type
        analysis_type = self.abc_analysis_type
        count = self.env['setu.stock.inventory.count'].browse(self._context.get('active_id'))
        domain.append(('inventory_count_id', '=', count.id))
        if self.report_type == 'ABC':
            if self.abc_analysis_type == 'all':
                product_detail += count.product_details_ids.filtered(lambda x: x.abc != False)
            elif analysis_type:
                product_detail += count.product_details_ids.filtered(lambda x: x.abc == abc_value)
        elif self.report_type == 'FSN':
            if self.stock_movement_type == 'all':
                product_detail += count.product_details_ids.filtered(lambda x: x.fsn != False)
            elif analysis_type:
                product_detail += count.product_details_ids.filtered(lambda x: x.fsn == fsn_value)
        product_ids = [product.product_id.id for product in product_detail]
        domain += [('product_id', 'in', product_ids)]
        if categories:
            domain += [('category_id', 'in', categories.ids)]
        if specific_products:
            domain += [('product_id', 'in', specific_products.ids)]
        removing_product_ids = self.env['setu.product.wise.abc.fsn'].search(domain)
        for product in removing_product_ids:
            count.product_details_ids = [(3, product.id)]
            count.product_ids = [(3, product.product_id.id)]
