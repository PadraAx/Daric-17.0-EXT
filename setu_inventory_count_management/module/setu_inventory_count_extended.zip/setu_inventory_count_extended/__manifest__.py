{
    'name': 'Setu Inventory Count Extended',
    'category': 'stock',
    'depends': ['setu_inventory_count_management', 'sale_stock'],
    'data': [
        'security/ir.model.access.csv',
        'db_function/get_stock_data.sql',
        'db_function/get_abc_inventory_count_data.sql',
        'db_function/get_inventory_count_data.sql',
        'db_function/get_products_stock_movements.sql',
        'db_function/get_inventory_turnover_ratio_data.sql',
        'db_function/get_products_opening_stock.sql',
        'db_function/get_inventory_fsn_inventory_count_report.sql',
        'views/inventory_count.xml',
        'views/inventory_count_planner.xml',
        'wizard/get_products.xml',
        'wizard/wizard.xml',
    ],
    'installable': True,
    'auto_install': False
}
